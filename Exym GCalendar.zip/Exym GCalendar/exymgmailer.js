// ==UserScript==
// @name         Add to Google Calendar
// @namespace    http://tampermonkey.net/
// @version      2024-12-10
// @description  try to take over the world!
// @author       You
// @match        https://imces.exym1.com/Patients/EditPatient.aspx
// @icon         https://www.google.com/s2/favicons?sz=64&domain=exym1.com
// @grant        none
// ==/UserScript==


(function() {
    'use strict';

    // Get the logged-in user's ID and clean it up
    let userId = document.getElementById("ctl00_Banner_logOff")?.textContent.trim();
    if (userId.startsWith("Log Off ")) {
        userId = userId.replace("Log Off ", "").trim();
    }

    if (!userId) {
        console.error("Unable to retrieve user ID");
        return;
    }

    // Get the Client's name
    let clientIdLong = document.getElementById("printctl00_Banner_ddlPatients")?.textContent.trim();
    let clientId = clientIdLong.split("(")[0].trim();
    var clientIdTrim = "";

    const parts = clientId.split(",");
    if (parts.length > 1) {
        const trimmedPart = parts[1].trim(); // Remove leading spaces from the second part

        const shortenedPart = trimmedPart.substring(0, 2); // Get the first two letters
        clientIdTrim = `${parts[0]}, ${shortenedPart}`; // Combine back with the first part

    } else {
        clientIdTrim = clientId; // If no comma, return the input unchanged
    }


    // Select the table
    const table = document.querySelector(".dataGrid.dgPActivities");
    if (!table) {
        console.error("Table not found");
        return;
    }

    // Get all rows in the table except the header
    const rows = table.querySelectorAll("tbody tr");

    rows.forEach(row => {
        // Get the columns
        const columns = row.querySelectorAll("td");

            const durationTime = columns[6]?.textContent.trim();
            const scheduledColumn = columns[3]?.textContent.trim();
            const scheduledTime = columns[9]?.textContent.trim();
            const personColumn = columns[8]?.textContent.trim();
        // Ensure the table has enough columns
       // if (columns.length > 1 && durationTime && scheduledColumn && scheduledTime && personColumn === userId) {

        if (columns.length > 1 && personColumn === userId) {

            const durationOther = columns[7]?.textContent.trim();
            const durationTotal = durationTime*1 + durationOther*1;
            let addHours = Math.floor(durationTotal / 60);
            let addMins = durationTotal % 60;


           console.log("time: "+addHours+" other: "+addMins);

            //if (personColumn === userId ) {

            if (durationTime && scheduledColumn && scheduledTime) {

                // Create a Google Calendar link
                const addToCalendarLink = document.createElement("a");
                addToCalendarLink.href = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${(clientId)}&dates=${formatDateForGoogleCalendar(scheduledColumn,scheduledTime,addHours, addMins)}`;
                addToCalendarLink.target = "_blank";
                addToCalendarLink.textContent = "Add to Google Calendar";

                // Append the link below the scheduled date
                const linkContainer = document.createElement("div");
                linkContainer.style.marginTop = "5px";
                linkContainer.appendChild(addToCalendarLink);
                columns[3].appendChild(linkContainer);
            } else {
                const addToCalendarLink = document.createElement("p");
                addToCalendarLink.textContent = "Missing Data";

                // Append the link below the scheduled date
                const linkContainer = document.createElement("div");
                linkContainer.style.marginTop = "5px";
                linkContainer.appendChild(addToCalendarLink);
                columns[3].appendChild(linkContainer);
        }
       }
    });

    // Function to format date for Google Calendar link
    function formatDateForGoogleCalendar(dateStr,timeStr,addHours, addMins) {
        // Adjust this parsing according to your date format
        const date = new Date(dateStr);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");



        const timeParts = timeStr.match(/(\d+):(\d+)(am|pm)/i);
        if (!timeParts) {
            console.error("Invalid time format");
            return null;
        }

        let hours = parseInt(timeParts[1], 10);
        const minutes = timeParts[2];
        const period = timeParts[3].toLowerCase();

        // Convert hours to 24-hour format if needed
        if (period === "pm" && hours !== 12) {
            hours += 12;
        } else if (period === "am" && hours === 12) {
            hours = 0;
        }


        const sumHours = hours*1 + addHours;
        const sumMins = minutes*1 + addMins;
        const endTime = sumHours*60 + sumMins;

            console.log("sumhours:"+sumHours+" summins:"+sumMins+" endTime:" +endTime);

        let endHours = Math.floor(endTime / 60);
        let endMins = endTime % 60;
         console.log("endhours:"+endHours+" endmins:"+endMins);

        // Format as HHMMSS for Google Calendar
        const formattedHours = String(hours).padStart(2, "0");
        const formattedHours2 = String( endHours).padStart(2, "0");
        const formattedMins2 = String(endMins).padStart(2, "0");


        // Google Calendar uses a format like YYYYMMDDTHHmmSSZ
        return `${year}${month}${day}T${formattedHours}${minutes}00/${year}${month}${day}T${formattedHours2}${formattedMins2}00`;
    }
})();
